/*
 * ps_pl.h
 *
 *  Created on: 2018��7��14��
 *      Author: wuyanwen
 */
#ifndef _PS_PL_H_
#define _PS_PL_H_

#define COUNTER_BASE_ADDR 		0x43C00000
#define COUNTER_DATA 			(COUNTER_BASE_ADDR + 0)
#define COUNTER_DATA_NUM 		(COUNTER_BASE_ADDR + 4)
#define BRIGHT                          (COUNTER_BASE_ADDR + 8)
#define COUNTER_DATA_RESERVED	(COUNTER_BASE_ADDR + c)

#endif
